package comp5216.sydney.edu.au.haplanet.model;

import android.widget.ImageView;
import android.widget.TextView;

public class ViewHolder {

    public ImageView ivImage;
    public TextView txtMessage;
    public TextView txtMessageTime;

    public ViewHolder(){}

}
